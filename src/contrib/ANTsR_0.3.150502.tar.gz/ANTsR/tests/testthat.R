library(testthat)
library(ANTsR)

test_check("ANTsR")
