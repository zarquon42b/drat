.onUnload <- function (libpath) {
  library.dynam.unload("Morpho", libpath)
}
