skin1 <- rgb(239,208,207,max=255)
skin2 <- rgb(216,185,182,max=255)
skin3 <- rgb(197,127,092,max=255)
skin4 <- rgb(150,073,040,max=255)
 
bone1 <- rgb(228, 209, 192,max=255)
bone2 <- rgb(255,243,170 ,max=255)
bone3 <- rgb(255,250,220,max=255) 
