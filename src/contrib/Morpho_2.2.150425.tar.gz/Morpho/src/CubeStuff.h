#ifndef CUBESTUFF_H_
#define CUBESTUFF_H_

RcppExport SEXP addo(SEXP array_);

RcppExport SEXP arrMean3(SEXP array_);

RcppExport SEXP scaleproc(SEXP array_);

#endif /*CUBESTUFF_H_*/
