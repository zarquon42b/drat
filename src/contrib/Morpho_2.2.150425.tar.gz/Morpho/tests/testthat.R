library(testthat)
library(Morpho)

test_check("Morpho")
