#ifndef _MorphoPermute_asymPerm_H
#define _MorphoPermute_asymPerm_H

#include <RcppArmadillo.h>

RcppExport SEXP asymPerm(SEXP asymr, SEXP groupsr, SEXP roundr);

#endif
