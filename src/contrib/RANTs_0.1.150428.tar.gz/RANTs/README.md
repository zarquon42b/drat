##RANTs (pun intended)

This is a playground for my playing with ANTs/ANTsR, to learn about image registration.

As ANTsR is a nice implementation into my favourite statistics environment R, I grasp this opportunity to get acquainted with the quite sophisticated task of 3D-image registration.
