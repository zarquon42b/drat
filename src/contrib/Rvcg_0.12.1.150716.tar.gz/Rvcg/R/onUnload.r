.onUnload <- function (libpath) {
  library.dynam.unload("Rvcg", libpath)
}
