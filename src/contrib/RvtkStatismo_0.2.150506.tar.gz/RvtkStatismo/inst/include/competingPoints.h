#include "ConstrainedModel.h"

IntegerVector sortInt(IntegerVector x);

RcppExport SEXP competingPoints(SEXP pPCA_,SEXP sample_, SEXP indices_, SEXP maha_);
