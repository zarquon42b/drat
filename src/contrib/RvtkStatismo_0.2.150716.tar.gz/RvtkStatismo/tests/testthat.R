library(testthat)
library(RvtkStatismo)

test_check("RvtkStatismo")
