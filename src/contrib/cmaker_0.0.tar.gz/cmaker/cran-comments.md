## Test environments
* local OS X install, R devel
* ubuntu 12.04 (on travis-ci), R devel
* No windows build - this release not intended for windows

## R CMD check results
There were no ERRORs or WARNINGs.

There was 1 NOTE:

* installed size is 36.1Mb

## Downstream dependencies

No downstream dependencies
