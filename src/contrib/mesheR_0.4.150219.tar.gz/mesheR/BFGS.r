require(Rvcg);require(lbfgs);require(RvtkStatismo);require(mesheR);require(Morpho);require(rgl)

ref <- vcgQEdecim(read.vtk("VSD001_femur.vtk"),tarface = 5000)
ref <- read.vtk("VSD001_femur.vtk")
tar <- read.vtk("VSD002_femur.vtk")

ref.lm <- as.matrix(read.csv("VSD001-lm.csv",row.names=1))
tar.lm <- as.matrix(read.csv("VSD002-lm.csv",row.names=1))
mymod <- statismoModelFromRepresenter(ref,kernel=list(c(50,50)),ncomp = 100,isoScale = 0.1)
mymodC <- statismoConstrainModel(mymod,tar.lm,ref.lm,2)
Bayes <- createBayes(mymod,sdmax = rep(10,50),align=T)
similarity = list(iterations=10,rhotol=pi/2)
affine = list(iterations=10,rhotol=pi/2)

### run the matching
matchGP <- gaussMatch(Bayes,tar,lm1 = ref.lm,lm2=tar.lm,iterations = 30,sigma = 30,gamma=2,toldist = 30,angtol = pi/2,nh=100,visualize = T,similarity = similarity,noinc = T)

model <- mymodC
#vars <- ComputeCoefficientsForDataset(model,matchGP)
vars <- rep(0,length(GetPCAVarianceVector(mymodC)))
mesh2 <- tar
pcbas <- GetPCABasisMatrix(model)
#BFGS <- function(model, mesh2) {
    chkres <- list()
    vars <- rep(0,length(GetPCAVarianceVector(model)))

    pcbas <- GetPCABasisMatrix(model)
    
    for(i in 1:4) {
        mm <- DrawSample(model,vars)
        cc <- vcgClostKD(mm,mesh2)
        clost <- vert2points(cc)
        objective <- function(x,clost,...) {
            mm <- DrawSample(model,x)
            x <- c(vert2points(mm))
            y <- clost
            d <- norm(x-y,type="2")^2
            return(d)
        }
        ob.grad <- function(x,mesh2,pcbas,cc=cc,...) {
            d <- as.vector(t(cbind(cc$quality,cc$quality,cc$quality)))
            hist(d)
            d2 <- matrix(0,3,ncol(pcbas))
            d2 <- NULL
            for (i in 1:ncol(pcbas)) {
                
                tmp0 <- 2*d*pcbas[,i]
                
                d2[i] <- sum(matrix(tmp0,3,length(tmp0)/3) ^2)
            }
            return(d2)
        }
        
        out1 <- optim(vars,objective,clost=clost,method="L-BFGS",control=list(maxit=25),pcbas=pcbas)
        chkres[[i]] <- out1
        vars <- out1$par
        
        print(paste("iteration",i))
        print(vars)
        print(out1$value)
    }
    
    out <- lbfgs(objective,ob.grad,vars=vars,pcbas=pcbas,mesh2=mesh2,max_iterations = 1,clost=clost)
   

    out1 <- optim(vars,objective,ob.grad,clost=clost,method="BFGS",control=list(maxit=100),pcbas=pcbas)
    dd <- DrawSample(model,vars)
    wire3d(dd,col=3,lwd=2)
    wire3d(mm)
    shade3d(tar,col=2)
