#ifndef _ANGCHECK_H__
#define _ANGCHECK_H__
#include "Rcpp.h"
using namespace Rcpp;


double dot(Rcpp::NumericVector c,Rcpp::NumericVector d);

double norm(Rcpp::NumericVector c);

#endif
