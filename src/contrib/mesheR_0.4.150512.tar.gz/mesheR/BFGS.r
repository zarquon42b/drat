require(Rvcg);require(lbfgs);require(RvtkStatismo);require(mesheR);require(Morpho);require(rgl)

ref <- vcgQEdecim(read.vtk("VSD001_femur.vtk"),tarface = 5000)
ref <- read.vtk("VSD001_femur.vtk")
tar <- read.vtk("VSD002_femur.vtk")

ref.lm <- as.matrix(read.csv("VSD001-lm.csv",row.names=1))
tar.lm <- as.matrix(read.csv("VSD002-lm.csv",row.names=1))
mymod <- statismoModelFromRepresenter(ref,kernel=list(c(50,50)),ncomp = 100,isoScale = 0.1)
mymodC <- statismoConstrainModel(mymod,tar.lm,ref.lm,2)

model <- mymodC
#vars <- ComputeCoefficientsForDataset(model,matchGP)
mesh2 <- tar
#BFGS <- function(model, mesh2) {
    chkres <- list()
    x <-

    pcbas <- GetOrthonormalPCABasisMatrix(model)
    #pcbas <- t(t(pcbas)/sqrt(GetPCAVarianceVector(model)))

myfun <- function(tt) {
    vals <- 0
    vars <- rep(0,length(GetPCAVarianceVector(model)))
    pcbas <- GetOrthonormalPCABasisMatrix(model)
    sds <- sqrt(GetPCAVarianceVector(model))
    for(i in 1:tt) {
        
        mm <- DrawSample(model,vars)
        cc <- vcgClostKD(mm,mesh2,sign = FALSE)
        clost <- vert2points(cc)
        
        out1 <- optim(vars,objective,ob.grad,clost=clost,method="BFGS",control=list(maxit=3),pcbas=pcbas,mesh2=mesh2,model=model)
        vars <- out1$par
        print(paste("iteration",i))
       # print(vars)
        vals[i] <- out1$value
        print(out1$value)
    }
        return(list(par=out1$par,vals=vals))
    }

    out <- lbfgs(objective,ob.grad,vars=vars,pcbas=pcbas,mesh2=mesh2,max_iterations = 4,clost=clost,model=model)
   
#vars <- vars/sqrt(GetPCAVarianceVector(model))
    out1 <- optim(vars,objective,ob.grad,clost=clost,method="BFGS",control=list(maxit=1),pcbas=pcbas,mesh2=mesh2,model=model)
estim <- DrawSample(model,dd$par*sds)

    wire3d(estim,col=3,lwd=2)
    wire3d(mm)
    shade3d(tar,col=2)

objective <- function(x,clost,model,...) {
    
    #sds <- sqrt(GetPCAVarianceVector(model))
    #x <- x*sds
    mm <- DrawSample(model,x)
    x <- c(vert2points(mm))
    y <- clost
    Area <- RvtkStatismo::vtkMeshInfo(mm)$surfaceArea/3
    VerArea <- Rvcg:::vcgOneRingArea(mm)$areaverts
    diffxy <- sqrt(rowSums((x-y)^2))
    diffxy <- sum(diffxy*VerArea)
    d <- diffxy/Area
    return(d)
}

ob.grad <- function(x,mesh2,pcbas,model,...) {
    #sds <- sqrt(GetPCAVarianceVector(model))
    #x <- x*sds
    mm <- DrawSample(model,x)
    
    cc <- vcgClostKD(mm,mesh2,sign=FALSE)
    d <- as.vector(t(cbind(cc$quality,cc$quality,cc$quality)))
                   
                   d2 <- NULL
     for (i in 1:ncol(pcbas)) {
         tmp0 <- 2*d*(pcbas[,i])
         d2[i] <- sum(tmp0^2)
                                        #d2[i] <- sum(matrix(tmp0,3,length(tmp0)/3) ^2)
     }
     return(d2)
 }
 objectiveFast <- function(x,clost,mm,...) {
            #mm <- DrawSample(model,x)
            x <- c(vert2points(mm))
            y <- clost
            Area <- RvtkStatismo::vtkMeshInfo(mm)$surfaceArea/3
            VerArea <- Rvcg:::vcgOneRingArea(mm)$areaverts
            diffxy <- sqrt(rowSums((x-y)^2))
            diffxy <- sum(diffxy*VerArea)
            d <- diffxy/Area
            return(d)
        }
